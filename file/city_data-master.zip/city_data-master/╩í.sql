/*
 Navicat Premium Data Transfer

 Source Server         : 111
 Source Server Type    : SQLite
 Source Server Version : 3030001
 Source Schema         : main

 Target Server Type    : SQLite
 Target Server Version : 3030001
 File Encoding         : 65001

 Date: 06/08/2024 10:36:00
*/

PRAGMA foreign_keys = false;

-- ----------------------------
-- Table structure for 省
-- ----------------------------
DROP TABLE IF EXISTS "省";
CREATE TABLE "省" (
  "名称" nvarchar(255) COLLATE NOCASE,
  "行政区划代码" char(6) NOT NULL COLLATE NOCASE
);

-- ----------------------------
-- Records of 省
-- ----------------------------
INSERT INTO "省" VALUES ('北京市', 110000);
INSERT INTO "省" VALUES ('天津市', 120000);
INSERT INTO "省" VALUES ('河北省', 130000);
INSERT INTO "省" VALUES ('山西省', 140000);
INSERT INTO "省" VALUES ('内蒙古自治区', 150000);
INSERT INTO "省" VALUES ('辽宁省', 210000);
INSERT INTO "省" VALUES ('吉林省', 220000);
INSERT INTO "省" VALUES ('黑龙江省', 230000);
INSERT INTO "省" VALUES ('上海市', 310000);
INSERT INTO "省" VALUES ('江苏省', 320000);
INSERT INTO "省" VALUES ('浙江省', 330000);
INSERT INTO "省" VALUES ('安徽省', 340000);
INSERT INTO "省" VALUES ('福建省', 350000);
INSERT INTO "省" VALUES ('江西省', 360000);
INSERT INTO "省" VALUES ('山东省', 370000);
INSERT INTO "省" VALUES ('河南省', 410000);
INSERT INTO "省" VALUES ('湖北省', 420000);
INSERT INTO "省" VALUES ('湖南省', 430000);
INSERT INTO "省" VALUES ('广东省', 440000);
INSERT INTO "省" VALUES ('广西壮族自治区', 450000);
INSERT INTO "省" VALUES ('海南省', 460000);
INSERT INTO "省" VALUES ('重庆市', 500000);
INSERT INTO "省" VALUES ('四川省', 510000);
INSERT INTO "省" VALUES ('贵州省', 520000);
INSERT INTO "省" VALUES ('云南省', 530000);
INSERT INTO "省" VALUES ('西藏自治区', 540000);
INSERT INTO "省" VALUES ('陕西省', 610000);
INSERT INTO "省" VALUES ('甘肃省', 620000);
INSERT INTO "省" VALUES ('青海省', 630000);
INSERT INTO "省" VALUES ('宁夏回族自治区', 640000);
INSERT INTO "省" VALUES ('新疆维吾尔自治区', 650000);
INSERT INTO "省" VALUES ('台湾省', 710000);
INSERT INTO "省" VALUES ('香港特别行政区', 810000);

PRAGMA foreign_keys = true;
